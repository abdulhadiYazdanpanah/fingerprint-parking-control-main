
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Motorcycle, Employee } from './Dashboard';
import { Edit, Database } from 'lucide-react';

interface MotorcycleManagementProps {
  motorcycles: Motorcycle[];
  setMotorcycles: React.Dispatch<React.SetStateAction<Motorcycle[]>>;
  employees: Employee[];
}

const MotorcycleManagement = ({ motorcycles, setMotorcycles, employees }: MotorcycleManagementProps) => {
  const [newMotorcycle, setNewMotorcycle] = useState({
    model: '',
    licensePlate: '',
    color: '',
    ownerId: ''
  });
  const [editingMotorcycle, setEditingMotorcycle] = useState<Motorcycle | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const colors = ['قرمز', 'آبی', 'سیاه', 'سفید', 'طوسی', 'سبز', 'زرد', 'نقره‌ای'];

  const addMotorcycle = () => {
    if (newMotorcycle.model.trim() && newMotorcycle.licensePlate.trim() && newMotorcycle.ownerId) {
      const motorcycle: Motorcycle = {
        id: `moto${String(motorcycles.length + 1).padStart(3, '0')}`,
        model: newMotorcycle.model,
        licensePlate: newMotorcycle.licensePlate,
        color: newMotorcycle.color,
        ownerId: newMotorcycle.ownerId,
        active: true,
        createdAt: new Date()
      };
      setMotorcycles([...motorcycles, motorcycle]);
      setNewMotorcycle({ model: '', licensePlate: '', color: '', ownerId: '' });
      setIsAddDialogOpen(false);
    }
  };

  const updateMotorcycle = () => {
    if (editingMotorcycle) {
      setMotorcycles(motorcycles.map(moto => 
        moto.id === editingMotorcycle.id ? editingMotorcycle : moto
      ));
      setEditingMotorcycle(null);
      setIsEditDialogOpen(false);
    }
  };

  const toggleMotorcycleStatus = (id: string) => {
    setMotorcycles(motorcycles.map(moto => 
      moto.id === id ? { ...moto, active: !moto.active } : moto
    ));
  };

  const getOwnerName = (ownerId: string) => {
    const owner = employees.find(emp => emp.id === ownerId);
    return owner ? owner.name : 'نامشخص';
  };

  const getColorBadgeStyle = (color: string) => {
    const colorMap: { [key: string]: string } = {
      'قرمز': 'bg-red-100 text-red-800',
      'آبی': 'bg-blue-100 text-blue-800',
      'سیاه': 'bg-gray-100 text-gray-800',
      'سفید': 'bg-slate-100 text-slate-800',
      'طوسی': 'bg-gray-100 text-gray-600',
      'سبز': 'bg-green-100 text-green-800',
      'زرد': 'bg-yellow-100 text-yellow-800',
      'نقره‌ای': 'bg-slate-100 text-slate-600'
    };
    return colorMap[color] || 'bg-gray-100 text-gray-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">مدیریت موتورسیکلت‌ها</h2>
          <p className="text-slate-600">افزودن، ویرایش و مدیریت اطلاعات موتورسیکلت‌ها</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700 text-white">
              + افزودن موتورسیکلت جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>افزودن موتورسیکلت جدید</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="model">مدل موتورسیکلت</Label>
                <Input
                  id="model"
                  value={newMotorcycle.model}
                  onChange={(e) => setNewMotorcycle({ ...newMotorcycle, model: e.target.value })}
                  placeholder="مثال: هوندا CG125"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="licensePlate">شماره پلاک</Label>
                <Input
                  id="licensePlate"
                  value={newMotorcycle.licensePlate}
                  onChange={(e) => setNewMotorcycle({ ...newMotorcycle, licensePlate: e.target.value })}
                  placeholder="مثال: 12ص345ت67"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="color">رنگ</Label>
                <Select value={newMotorcycle.color} onValueChange={(value) => setNewMotorcycle({ ...newMotorcycle, color: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="رنگ موتورسیکلت را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    {colors.map((color) => (
                      <SelectItem key={color} value={color}>{color}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="ownerId">مالک</Label>
                <Select value={newMotorcycle.ownerId} onValueChange={(value) => setNewMotorcycle({ ...newMotorcycle, ownerId: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="مالک موتورسیکلت را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.filter(emp => emp.active).map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} ({employee.id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={addMotorcycle} className="flex-1 bg-green-600 hover:bg-green-700">
                  افزودن
                </Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                  انصراف
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {motorcycles.map((motorcycle) => (
          <Card key={motorcycle.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-green-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Database className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{motorcycle.model}</CardTitle>
                    <p className="text-sm text-slate-500">شناسه: {motorcycle.id}</p>
                  </div>
                </div>
                <Badge variant={motorcycle.active ? "default" : "secondary"}>
                  {motorcycle.active ? 'فعال' : 'غیرفعال'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-sm">
                  <span className="text-slate-600">شماره پلاک: </span>
                  <span className="font-mono bg-slate-100 px-2 py-1 rounded text-xs">
                    {motorcycle.licensePlate}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-600">رنگ:</span>
                  <Badge className={getColorBadgeStyle(motorcycle.color)}>
                    {motorcycle.color}
                  </Badge>
                </div>
                <div className="text-sm">
                  <span className="text-slate-600">مالک: </span>
                  <span className="font-medium">{getOwnerName(motorcycle.ownerId)}</span>
                </div>
                <div className="text-sm text-slate-600">
                  تاریخ ثبت: {motorcycle.createdAt.toLocaleDateString('fa-IR')}
                </div>
                <div className="flex gap-2 pt-2">
                  <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => setEditingMotorcycle(motorcycle)}
                      >
                        <Edit className="w-4 h-4 ml-1" />
                        ویرایش
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>ویرایش اطلاعات موتورسیکلت</DialogTitle>
                      </DialogHeader>
                      {editingMotorcycle && (
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="edit-model">مدل موتورسیکلت</Label>
                            <Input
                              id="edit-model"
                              value={editingMotorcycle.model}
                              onChange={(e) => setEditingMotorcycle({ 
                                ...editingMotorcycle, 
                                model: e.target.value 
                              })}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="edit-licensePlate">شماره پلاک</Label>
                            <Input
                              id="edit-licensePlate"
                              value={editingMotorcycle.licensePlate}
                              onChange={(e) => setEditingMotorcycle({ 
                                ...editingMotorcycle, 
                                licensePlate: e.target.value 
                              })}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="edit-color">رنگ</Label>
                            <Select 
                              value={editingMotorcycle.color} 
                              onValueChange={(value) => setEditingMotorcycle({ 
                                ...editingMotorcycle, 
                                color: value 
                              })}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {colors.map((color) => (
                                  <SelectItem key={color} value={color}>{color}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="edit-ownerId">مالک</Label>
                            <Select 
                              value={editingMotorcycle.ownerId} 
                              onValueChange={(value) => setEditingMotorcycle({ 
                                ...editingMotorcycle, 
                                ownerId: value 
                              })}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {employees.filter(emp => emp.active).map((employee) => (
                                  <SelectItem key={employee.id} value={employee.id}>
                                    {employee.name} ({employee.id})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex gap-2 pt-4">
                            <Button onClick={updateMotorcycle} className="flex-1 bg-green-600 hover:bg-green-700">
                              ذخیره تغییرات
                            </Button>
                            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                              انصراف
                            </Button>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  
                  <Button 
                    variant={motorcycle.active ? "destructive" : "default"}
                    size="sm" 
                    className="flex-1"
                    onClick={() => toggleMotorcycleStatus(motorcycle.id)}
                  >
                    {motorcycle.active ? 'غیرفعال کردن' : 'فعال کردن'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {motorcycles.length === 0 && (
        <Card className="p-12">
          <div className="text-center text-slate-500">
            <Database className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium mb-2">هیچ موتورسیکلتی ثبت نشده است</h3>
            <p>برای شروع، موتورسیکلت جدیدی اضافه کنید</p>
          </div>
        </Card>
      )}
    </div>
  );
};

export default MotorcycleManagement;
