
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Employee } from './Dashboard';
import { Edit, User } from 'lucide-react';

interface UserManagementProps {
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
}

const UserManagement = ({ employees, setEmployees }: UserManagementProps) => {
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    fingerprint: ''
  });
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const addEmployee = () => {
    if (newEmployee.name.trim()) {
      const employee: Employee = {
        id: `emp${String(employees.length + 1).padStart(3, '0')}`,
        name: newEmployee.name,
        fingerprint: newEmployee.fingerprint || `fp${Date.now()}`,
        active: true,
        createdAt: new Date()
      };
      setEmployees([...employees, employee]);
      setNewEmployee({ name: '', fingerprint: '' });
      setIsAddDialogOpen(false);
    }
  };

  const updateEmployee = () => {
    if (editingEmployee) {
      setEmployees(employees.map(emp => 
        emp.id === editingEmployee.id ? editingEmployee : emp
      ));
      setEditingEmployee(null);
      setIsEditDialogOpen(false);
    }
  };

  const toggleEmployeeStatus = (id: string) => {
    setEmployees(employees.map(emp => 
      emp.id === id ? { ...emp, active: !emp.active } : emp
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">مدیریت همکاران</h2>
          <p className="text-slate-600">افزودن، ویرایش و مدیریت اطلاعات همکاران</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              + افزودن همکار جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>افزودن همکار جدید</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">نام همکار</Label>
                <Input
                  id="name"
                  value={newEmployee.name}
                  onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                  placeholder="نام کامل همکار را وارد کنید"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="fingerprint">شناسه اثر انگشت (اختیاری)</Label>
                <Input
                  id="fingerprint"
                  value={newEmployee.fingerprint}
                  onChange={(e) => setNewEmployee({ ...newEmployee, fingerprint: e.target.value })}
                  placeholder="در صورت عدم وارد کردن، خودکار تولید می‌شود"
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={addEmployee} className="flex-1 bg-green-600 hover:bg-green-700">
                  افزودن
                </Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                  انصراف
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {employees.map((employee) => (
          <Card key={employee.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{employee.name}</CardTitle>
                    <p className="text-sm text-slate-500">شناسه: {employee.id}</p>
                  </div>
                </div>
                <Badge variant={employee.active ? "default" : "secondary"}>
                  {employee.active ? 'فعال' : 'غیرفعال'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-sm">
                  <span className="text-slate-600">اثر انگشت: </span>
                  <span className="font-mono bg-slate-100 px-2 py-1 rounded text-xs">
                    {employee.fingerprint}
                  </span>
                </div>
                <div className="text-sm text-slate-600">
                  تاریخ ثبت: {employee.createdAt.toLocaleDateString('fa-IR')}
                </div>
                <div className="flex gap-2 pt-2">
                  <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => setEditingEmployee(employee)}
                      >
                        <Edit className="w-4 h-4 ml-1" />
                        ویرایش
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>ویرایش اطلاعات همکار</DialogTitle>
                      </DialogHeader>
                      {editingEmployee && (
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="edit-name">نام همکار</Label>
                            <Input
                              id="edit-name"
                              value={editingEmployee.name}
                              onChange={(e) => setEditingEmployee({ 
                                ...editingEmployee, 
                                name: e.target.value 
                              })}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor="edit-fingerprint">شناسه اثر انگشت</Label>
                            <Input
                              id="edit-fingerprint"
                              value={editingEmployee.fingerprint}
                              onChange={(e) => setEditingEmployee({ 
                                ...editingEmployee, 
                                fingerprint: e.target.value 
                              })}
                              className="mt-1"
                            />
                          </div>
                          <div className="flex gap-2 pt-4">
                            <Button onClick={updateEmployee} className="flex-1 bg-green-600 hover:bg-green-700">
                              ذخیره تغییرات
                            </Button>
                            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                              انصراف
                            </Button>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  
                  <Button 
                    variant={employee.active ? "destructive" : "default"}
                    size="sm" 
                    className="flex-1"
                    onClick={() => toggleEmployeeStatus(employee.id)}
                  >
                    {employee.active ? 'غیرفعال کردن' : 'فعال کردن'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {employees.length === 0 && (
        <Card className="p-12">
          <div className="text-center text-slate-500">
            <User className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium mb-2">هیچ همکاری ثبت نشده است</h3>
            <p>برای شروع، همکار جدیدی اضافه کنید</p>
          </div>
        </Card>
      )}
    </div>
  );
};

export default UserManagement;
