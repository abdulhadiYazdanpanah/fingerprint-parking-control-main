
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { EntryExit, Motorcycle, Employee } from './Dashboard';
import { Calendar, User, Database, Clock, LogIn } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

interface ReportsProps {
  entryExitLogs: EntryExit[];
  motorcycles: Motorcycle[];
  employees: Employee[];
}

const Reports = ({ entryExitLogs, motorcycles, employees }: ReportsProps) => {
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    employeeId: 'all',
    motorcycleId: 'all',
    type: 'all'
  });

  const [reportType, setReportType] = useState('summary');

  const filteredLogs = entryExitLogs.filter(log => {
    const logDate = new Date(log.timestamp);
    const fromDate = filters.dateFrom ? new Date(filters.dateFrom) : null;
    const toDate = filters.dateTo ? new Date(filters.dateTo) : null;

    if (fromDate && logDate < fromDate) return false;
    if (toDate && logDate > toDate) return false;
    if (filters.employeeId !== 'all' && log.employeeId !== filters.employeeId) return false;
    if (filters.motorcycleId !== 'all' && log.motorcycleId !== filters.motorcycleId) return false;
    if (filters.type !== 'all' && log.type !== filters.type) return false;

    return true;
  });

  const getEmployeeInfo = (employeeId: string) => {
    return employees.find(emp => emp.id === employeeId);
  };

  const getMotorcycleInfo = (motorcycleId: string) => {
    return motorcycles.find(moto => moto.id === motorcycleId);
  };

  // Generate daily activity chart data
  const getDailyActivityData = () => {
    const dailyData: { [key: string]: { date: string; entries: number; exits: number } } = {};
    
    filteredLogs.forEach(log => {
      const date = new Date(log.timestamp).toLocaleDateString('fa-IR');
      if (!dailyData[date]) {
        dailyData[date] = { date, entries: 0, exits: 0 };
      }
      if (log.type === 'entry') {
        dailyData[date].entries++;
      } else {
        dailyData[date].exits++;
      }
    });

    return Object.values(dailyData).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  // Generate employee activity data
  const getEmployeeActivityData = () => {
    const employeeData: { [key: string]: { name: string; count: number } } = {};
    
    filteredLogs.forEach(log => {
      const employee = getEmployeeInfo(log.employeeId);
      if (employee) {
        if (!employeeData[employee.id]) {
          employeeData[employee.id] = { name: employee.name, count: 0 };
        }
        employeeData[employee.id].count++;
      }
    });

    return Object.values(employeeData);
  };

  // Generate entry/exit type distribution
  const getTypeDistribution = () => {
    const entries = filteredLogs.filter(log => log.type === 'entry').length;
    const exits = filteredLogs.filter(log => log.type === 'exit').length;
    
    return [
      { name: 'ورود', value: entries, color: '#10b981' },
      { name: 'خروج', value: exits, color: '#ef4444' }
    ];
  };

  const clearFilters = () => {
    setFilters({
      dateFrom: '',
      dateTo: '',
      employeeId: 'all',
      motorcycleId: 'all',
      type: 'all'
    });
  };

  const dailyData = getDailyActivityData();
  const employeeData = getEmployeeActivityData();
  const typeDistribution = getTypeDistribution();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">گزارش‌گیری پیشرفته</h2>
        <p className="text-slate-600">تحلیل و بررسی آمار ورود و خروج موتورسیکلت‌ها</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            فیلترهای گزارش
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            <div>
              <Label htmlFor="dateFrom">از تاریخ</Label>
              <Input
                id="dateFrom"
                type="date"
                value={filters.dateFrom}
                onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="dateTo">تا تاریخ</Label>
              <Input
                id="dateTo"
                type="date"
                value={filters.dateTo}
                onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="employeeId">همکار</Label>
              <Select value={filters.employeeId} onValueChange={(value) => setFilters({ ...filters, employeeId: value })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="همه همکاران" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه همکاران</SelectItem>
                  {employees.map((employee) => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="motorcycleId">موتورسیکلت</Label>
              <Select value={filters.motorcycleId} onValueChange={(value) => setFilters({ ...filters, motorcycleId: value })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="همه موتورسیکلت‌ها" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه موتورسیکلت‌ها</SelectItem>
                  {motorcycles.map((motorcycle) => (
                    <SelectItem key={motorcycle.id} value={motorcycle.id}>
                      {motorcycle.model} - {motorcycle.licensePlate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="type">نوع عملیات</Label>
              <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="همه عملیات" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه عملیات</SelectItem>
                  <SelectItem value="entry">ورود</SelectItem>
                  <SelectItem value="exit">خروج</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button variant="outline" onClick={clearFilters} className="w-full">
                پاک کردن فیلترها
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="text-center">
              <LogIn className="w-8 h-8 mx-auto mb-2 text-blue-200" />
              <p className="text-blue-100 text-sm">کل فعالیت‌ها</p>
              <p className="text-3xl font-bold">{filteredLogs.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="text-center">
              <User className="w-8 h-8 mx-auto mb-2 text-green-200" />
              <p className="text-green-100 text-sm">کل ورودی‌ها</p>
              <p className="text-3xl font-bold">
                {filteredLogs.filter(log => log.type === 'entry').length}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="text-center">
              <Database className="w-8 h-8 mx-auto mb-2 text-red-200" />
              <p className="text-red-100 text-sm">کل خروجی‌ها</p>
              <p className="text-3xl font-bold">
                {filteredLogs.filter(log => log.type === 'exit').length}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="text-center">
              <Clock className="w-8 h-8 mx-auto mb-2 text-purple-200" />
              <p className="text-purple-100 text-sm">همکاران فعال</p>
              <p className="text-3xl font-bold">
                {new Set(filteredLogs.map(log => log.employeeId)).size}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Activity Chart */}
        <Card>
          <CardHeader>
            <CardTitle>فعالیت روزانه</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="entries" stroke="#10b981" name="ورود" />
                <Line type="monotone" dataKey="exits" stroke="#ef4444" name="خروج" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Type Distribution Chart */}
        <Card>
          <CardHeader>
            <CardTitle>توزیع نوع عملیات</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={typeDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={(entry) => `${entry.name}: ${entry.value}`}
                >
                  {typeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Employee Activity Chart */}
      <Card>
        <CardHeader>
          <CardTitle>فعالیت همکاران</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={employeeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Detailed Log Table */}
      <Card>
        <CardHeader>
          <CardTitle>جزئیات فعالیت‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredLogs.map((log) => {
              const motorcycle = getMotorcycleInfo(log.motorcycleId);
              const employee = getEmployeeInfo(log.employeeId);

              if (!motorcycle || !employee) return null;

              return (
                <div key={log.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <Badge className={log.type === 'entry' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                      {log.type === 'entry' ? 'ورود' : 'خروج'}
                    </Badge>
                    <div>
                      <p className="font-medium">{motorcycle.model} - {motorcycle.licensePlate}</p>
                      <p className="text-sm text-slate-600">{employee.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{new Date(log.timestamp).toLocaleDateString('fa-IR')}</p>
                    <p className="text-xs text-slate-500">{new Date(log.timestamp).toLocaleTimeString('fa-IR')}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredLogs.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-medium mb-2">هیچ داده‌ای یافت نشد</h3>
              <p>با تغییر فیلترها، گزارش‌های بیشتری مشاهده کنید</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;
