
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Motorcycle, Employee, EntryExit } from './Dashboard';
import { Clock, User, Database } from 'lucide-react';

interface ParkingStatusProps {
  motorcycles: Motorcycle[];
  employees: Employee[];
  entryExitLogs: EntryExit[];
}

const ParkingStatus = ({ motorcycles, employees, entryExitLogs }: ParkingStatusProps) => {
  const getMotorcycleInfo = (motorcycleId: string) => {
    return motorcycles.find(moto => moto.id === motorcycleId);
  };

  const getEmployeeInfo = (employeeId: string) => {
    return employees.find(emp => emp.id === employeeId);
  };

  const getCurrentlyParked = () => {
    const parkedMap = new Map();
    
    // Process logs to find current status
    entryExitLogs
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .forEach(log => {
        if (!parkedMap.has(log.motorcycleId)) {
          parkedMap.set(log.motorcycleId, log);
        }
      });

    return Array.from(parkedMap.values()).filter(log => log.status === 'parked');
  };

  const currentlyParked = getCurrentlyParked();

  const getStatusColor = (status: string) => {
    return status === 'parked' ? 'bg-green-500' : 'bg-red-500';
  };

  const getStatusText = (status: string) => {
    return status === 'parked' ? 'پارک شده' : 'خارج شده';
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">وضعیت فعلی پارکینگ</h2>
        <p className="text-slate-600">نمایش لحظه‌ای وضعیت موتورسیکلت‌های موجود در پارکینگ</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentlyParked.map((log) => {
          const motorcycle = getMotorcycleInfo(log.motorcycleId);
          const employee = getEmployeeInfo(log.employeeId);

          if (!motorcycle || !employee) return null;

          return (
            <Card key={log.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-green-500 bg-gradient-to-r from-green-50 to-white">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-4 h-4 rounded-full ${getStatusColor(log.status)} animate-pulse`}></div>
                    <div>
                      <CardTitle className="text-lg">{motorcycle.model}</CardTitle>
                      <p className="text-sm text-slate-500">{motorcycle.licensePlate}</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    {getStatusText(log.status)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-600">مالک:</span>
                    <span className="font-medium">{employee.name}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Database className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-600">شناسه:</span>
                    <span className="font-mono bg-slate-100 px-2 py-1 rounded text-xs">
                      {motorcycle.id}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-600">زمان ورود:</span>
                    <span className="text-xs">
                      {new Date(log.timestamp).toLocaleString('fa-IR')}
                    </span>
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span>رنگ: {motorcycle.color}</span>
                      <span>نوع: {log.type === 'entry' ? 'ورود' : 'خروج'}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {currentlyParked.length === 0 && (
        <Card className="p-12 text-center">
          <div className="text-slate-500">
            <Database className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-medium mb-2">پارکینگ خالی است</h3>
            <p className="text-sm">در حال حاضر هیچ موتورسیکلتی در پارکینگ پارک نشده است</p>
          </div>
        </Card>
      )}

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-blue-100 text-sm">کل ظرفیت</p>
              <p className="text-2xl font-bold">{motorcycles.filter(m => m.active).length}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-green-100 text-sm">پارک شده</p>
              <p className="text-2xl font-bold">{currentlyParked.length}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-orange-100 text-sm">خالی</p>
              <p className="text-2xl font-bold">
                {motorcycles.filter(m => m.active).length - currentlyParked.length}
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-purple-100 text-sm">درصد اشغال</p>
              <p className="text-2xl font-bold">
                {motorcycles.filter(m => m.active).length > 0 
                  ? Math.round((currentlyParked.length / motorcycles.filter(m => m.active).length) * 100)
                  : 0}%
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ParkingStatus;
