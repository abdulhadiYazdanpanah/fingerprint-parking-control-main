
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import UserManagement from './UserManagement';
import MotorcycleManagement from './MotorcycleManagement';
import ParkingStatus from './ParkingStatus';
import EntryExitLog from './EntryExitLog';
import Reports from './Reports';
import { Users, Clock, Database, User } from 'lucide-react';

export interface Employee {
  id: string;
  name: string;
  fingerprint?: string;
  active: boolean;
  createdAt: Date;
}

export interface Motorcycle {
  id: string;
  model: string;
  licensePlate: string;
  color: string;
  ownerId: string;
  active: boolean;
  createdAt: Date;
}

export interface EntryExit {
  id: string;
  motorcycleId: string;
  employeeId: string;
  type: 'entry' | 'exit';
  timestamp: Date;
  confirmedBy: string;
  status: 'parked' | 'departed';
}

const Dashboard = () => {
  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: 'emp001',
      name: 'علی احمدی',
      fingerprint: 'fp001',
      active: true,
      createdAt: new Date('2024-01-15')
    },
    {
      id: 'emp002', 
      name: 'فاطمه رضایی',
      fingerprint: 'fp002',
      active: true,
      createdAt: new Date('2024-01-20')
    },
    {
      id: 'emp003',
      name: 'محمد کریمی',
      fingerprint: 'fp003', 
      active: true,
      createdAt: new Date('2024-02-01')
    }
  ]);

  const [motorcycles, setMotorcycles] = useState<Motorcycle[]>([
    {
      id: 'moto001',
      model: 'هوندا CG125',
      licensePlate: '12ص345ت67',
      color: 'قرمز',
      ownerId: 'emp001',
      active: true,
      createdAt: new Date('2024-01-15')
    },
    {
      id: 'moto002',
      model: 'یاماها YBR125',
      licensePlate: '34د567ب89',
      color: 'آبی',
      ownerId: 'emp002',
      active: true,
      createdAt: new Date('2024-01-20')
    },
    {
      id: 'moto003',
      model: 'کاوازاکی Z125',
      licensePlate: '56ا789ج12',
      color: 'سیاه',
      ownerId: 'emp003',
      active: true,
      createdAt: new Date('2024-02-01')
    }
  ]);

  const [entryExitLogs, setEntryExitLogs] = useState<EntryExit[]>([
    {
      id: 'log001',
      motorcycleId: 'moto001',
      employeeId: 'emp001',
      type: 'entry',
      timestamp: new Date('2024-06-11T08:30:00'),
      confirmedBy: 'manager001',
      status: 'parked'
    },
    {
      id: 'log002',
      motorcycleId: 'moto002',
      employeeId: 'emp002',
      type: 'entry',
      timestamp: new Date('2024-06-11T09:15:00'),
      confirmedBy: 'manager001',
      status: 'parked'
    }
  ]);

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const totalEmployees = employees.filter(emp => emp.active).length;
  const totalMotorcycles = motorcycles.filter(moto => moto.active).length;
  const currentlyParked = entryExitLogs.filter(log => log.status === 'parked').length;
  const todayEntries = entryExitLogs.filter(log => {
    const today = new Date();
    const logDate = new Date(log.timestamp);
    return logDate.toDateString() === today.toDateString();
  }).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-slate-800 mb-2">
                🏍️ سیستم مدیریت پارکینگ موتورسیکلت
              </h1>
              <p className="text-slate-600">
                مدیریت هوشمند ورود و خروج موتورسیکلت‌ها با تایید اثر انگشت
              </p>
            </div>
            <div className="flex flex-col items-center md:items-end gap-2">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Clock className="w-4 h-4" />
                <span>{currentTime.toLocaleString('fa-IR')}</span>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                سیستم آنلاین
              </Badge>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">کل همکاران</p>
                  <p className="text-3xl font-bold">{totalEmployees}</p>
                </div>
                <Users className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm font-medium">کل موتورسیکلت‌ها</p>
                  <p className="text-3xl font-bold">{totalMotorcycles}</p>
                </div>
                <Database className="w-8 h-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-amber-500 to-amber-600 text-white border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-amber-100 text-sm font-medium">موتورها در پارکینگ</p>
                  <p className="text-3xl font-bold">{currentlyParked}</p>
                </div>
                <User className="w-8 h-8 text-amber-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">ورودی‌های امروز</p>
                  <p className="text-3xl font-bold">{todayEntries}</p>
                </div>
                <Clock className="w-8 h-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card className="bg-white shadow-xl border-0 rounded-2xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-6">
            <CardTitle className="text-xl font-semibold">پنل مدیریت</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="status" className="w-full">
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 bg-slate-100 rounded-none">
                <TabsTrigger value="status" className="data-[state=active]:bg-white">
                  وضعیت پارکینگ
                </TabsTrigger>
                <TabsTrigger value="employees" className="data-[state=active]:bg-white">
                  مدیریت همکاران
                </TabsTrigger>
                <TabsTrigger value="motorcycles" className="data-[state=active]:bg-white">
                  مدیریت موتورسیکلت‌ها
                </TabsTrigger>
                <TabsTrigger value="logs" className="data-[state=active]:bg-white">
                  ثبت ورود/خروج
                </TabsTrigger>
                <TabsTrigger value="reports" className="data-[state=active]:bg-white">
                  گزارش‌گیری
                </TabsTrigger>
              </TabsList>

              <div className="p-6">
                <TabsContent value="status">
                  <ParkingStatus 
                    motorcycles={motorcycles}
                    employees={employees}
                    entryExitLogs={entryExitLogs}
                  />
                </TabsContent>

                <TabsContent value="employees">
                  <UserManagement 
                    employees={employees}
                    setEmployees={setEmployees}
                  />
                </TabsContent>

                <TabsContent value="motorcycles">
                  <MotorcycleManagement 
                    motorcycles={motorcycles}
                    setMotorcycles={setMotorcycles}
                    employees={employees}
                  />
                </TabsContent>

                <TabsContent value="logs">
                  <EntryExitLog 
                    entryExitLogs={entryExitLogs}
                    setEntryExitLogs={setEntryExitLogs}
                    motorcycles={motorcycles}
                    employees={employees}
                  />
                </TabsContent>

                <TabsContent value="reports">
                  <Reports 
                    entryExitLogs={entryExitLogs}
                    motorcycles={motorcycles}
                    employees={employees}
                  />
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
