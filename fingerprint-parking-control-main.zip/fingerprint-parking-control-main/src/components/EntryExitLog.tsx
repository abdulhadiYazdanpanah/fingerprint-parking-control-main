
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { EntryExit, Motorcycle, Employee } from './Dashboard';
import { Clock, User, Database, LogIn } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EntryExitLogProps {
  entryExitLogs: EntryExit[];
  setEntryExitLogs: React.Dispatch<React.SetStateAction<EntryExit[]>>;
  motorcycles: Motorcycle[];
  employees: Employee[];
}

const EntryExitLog = ({ entryExitLogs, setEntryExitLogs, motorcycles, employees }: EntryExitLogProps) => {
  const [newLog, setNewLog] = useState({
    motorcycleId: '',
    employeeId: '',
    type: 'entry' as 'entry' | 'exit',
    confirmedBy: ''
  });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [fingerprintAuth, setFingerprintAuth] = useState({
    isAuthenticating: false,
    authType: '' as 'employee' | 'manager' | '',
    requiredFor: '' as 'entry' | 'exit' | ''
  });

  const { toast } = useToast();

  const getCurrentStatus = (motorcycleId: string) => {
    const motorcycleLogs = entryExitLogs
      .filter(log => log.motorcycleId === motorcycleId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return motorcycleLogs.length > 0 ? motorcycleLogs[0].status : 'departed';
  };

  const simulateFingerprintAuth = async (employeeId: string, authType: 'employee' | 'manager') => {
    setFingerprintAuth({ isAuthenticating: true, authType, requiredFor: newLog.type });
    
    // Simulate fingerprint authentication
    return new Promise((resolve) => {
      setTimeout(() => {
        setFingerprintAuth({ isAuthenticating: false, authType: '', requiredFor: '' });
        resolve(true);
      }, 2000);
    });
  };

  const addEntryExitLog = async () => {
    if (!newLog.motorcycleId || !newLog.employeeId) {
      toast({
        title: "خطا",
        description: "لطفاً تمام فیلدهای ضروری را پر کنید",
        variant: "destructive"
      });
      return;
    }

    const currentStatus = getCurrentStatus(newLog.motorcycleId);
    
    // Validate entry/exit logic
    if (newLog.type === 'entry' && currentStatus === 'parked') {
      toast({
        title: "خطا",
        description: "این موتورسیکلت در حال حاضر در پارکینگ است",
        variant: "destructive"
      });
      return;
    }
    
    if (newLog.type === 'exit' && currentStatus === 'departed') {
      toast({
        title: "خطا", 
        description: "این موتورسیکلت در حال حاضر در پارکینگ نیست",
        variant: "destructive"
      });
      return;
    }

    try {
      // Simulate fingerprint authentication based on type
      if (newLog.type === 'exit') {
        // For exit: employee fingerprint required
        await simulateFingerprintAuth(newLog.employeeId, 'employee');
        toast({
          title: "احراز هویت موفق",
          description: "اثر انگشت همکار تایید شد",
        });
      } else {
        // For entry: manager fingerprint required
        await simulateFingerprintAuth('manager001', 'manager');
        toast({
          title: "احراز هویت موفق", 
          description: "اثر انگشت مسئول پارکینگ تایید شد",
        });
      }

      const log: EntryExit = {
        id: `log${String(entryExitLogs.length + 1).padStart(3, '0')}`,
        motorcycleId: newLog.motorcycleId,
        employeeId: newLog.employeeId,
        type: newLog.type,
        timestamp: new Date(),
        confirmedBy: newLog.type === 'entry' ? 'manager001' : newLog.employeeId,
        status: newLog.type === 'entry' ? 'parked' : 'departed'
      };

      setEntryExitLogs([...entryExitLogs, log]);
      setNewLog({ motorcycleId: '', employeeId: '', type: 'entry', confirmedBy: '' });
      setIsAddDialogOpen(false);
      
      toast({
        title: "ثبت موفق",
        description: `${newLog.type === 'entry' ? 'ورود' : 'خروج'} موتورسیکلت با موفقیت ثبت شد`,
      });

    } catch (error) {
      toast({
        title: "خطا در احراز هویت",
        description: "لطفاً دوباره تلاش کنید",
        variant: "destructive"
      });
    }
  };

  const getMotorcycleInfo = (motorcycleId: string) => {
    return motorcycles.find(moto => moto.id === motorcycleId);
  };

  const getEmployeeInfo = (employeeId: string) => {
    return employees.find(emp => emp.id === employeeId);
  };

  const getTypeColor = (type: string) => {
    return type === 'entry' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const getTypeText = (type: string) => {
    return type === 'entry' ? 'ورود' : 'خروج';
  };

  const sortedLogs = entryExitLogs.sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">ثبت ورود و خروج</h2>
          <p className="text-slate-600">مدیریت ورود و خروج موتورسیکلت‌ها با تایید اثر انگشت</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              + ثبت ورود/خروج جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>ثبت ورود/خروج موتورسیکلت</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="type">نوع عملیات</Label>
                <Select value={newLog.type} onValueChange={(value: 'entry' | 'exit') => setNewLog({ ...newLog, type: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entry">ورود به پارکینگ</SelectItem>
                    <SelectItem value="exit">خروج از پارکینگ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="motorcycleId">موتورسیکلت</Label>
                <Select value={newLog.motorcycleId} onValueChange={(value) => setNewLog({ ...newLog, motorcycleId: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="موتورسیکلت را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    {motorcycles.filter(moto => moto.active).map((motorcycle) => (
                      <SelectItem key={motorcycle.id} value={motorcycle.id}>
                        {motorcycle.model} - {motorcycle.licensePlate}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="employeeId">همکار</Label>
                <Select value={newLog.employeeId} onValueChange={(value) => setNewLog({ ...newLog, employeeId: value })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="همکار را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.filter(emp => emp.active).map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} ({employee.id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {fingerprintAuth.isAuthenticating && (
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-center">
                    <div className="animate-pulse text-blue-600 mb-2">🔒</div>
                    <p className="text-sm text-blue-800">
                      در حال احراز هویت اثر انگشت...
                    </p>
                    <p className="text-xs text-blue-600 mt-1">
                      {fingerprintAuth.authType === 'employee' 
                        ? 'لطفاً اثر انگشت همکار را روی سنسور قرار دهید'
                        : 'لطفاً اثر انگشت مسئول پارکینگ را روی سنسور قرار دهید'
                      }
                    </p>
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={addEntryExitLog} 
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  disabled={fingerprintAuth.isAuthenticating}
                >
                  {fingerprintAuth.isAuthenticating ? 'در حال بررسی...' : 'ثبت'}
                </Button>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                  انصراف
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {sortedLogs.map((log) => {
          const motorcycle = getMotorcycleInfo(log.motorcycleId);
          const employee = getEmployeeInfo(log.employeeId);

          if (!motorcycle || !employee) return null;

          return (
            <Card key={log.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      log.type === 'entry' ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      <LogIn className={`w-6 h-6 ${
                        log.type === 'entry' ? 'text-green-600' : 'text-red-600 rotate-180'
                      }`} />
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Badge className={getTypeColor(log.type)}>
                          {getTypeText(log.type)}
                        </Badge>
                        <span className="font-medium">{motorcycle.model}</span>
                        <span className="text-sm text-slate-500">({motorcycle.licensePlate})</span>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <div className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          <span>{employee.name}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{new Date(log.timestamp).toLocaleString('fa-IR')}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="outline" className="text-xs">
                      شناسه: {log.id}
                    </Badge>
                    <div className="text-xs text-slate-500">
                      تایید شده توسط: {log.confirmedBy}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {entryExitLogs.length === 0 && (
        <Card className="p-12">
          <div className="text-center text-slate-500">
            <LogIn className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium mb-2">هیچ فعالیتی ثبت نشده است</h3>
            <p>ورود و خروج موتورسیکلت‌ها در اینجا نمایش داده می‌شود</p>
          </div>
        </Card>
      )}
    </div>
  );
};

export default EntryExitLog;
